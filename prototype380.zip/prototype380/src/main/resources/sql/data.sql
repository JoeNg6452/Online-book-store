INSERT INTO users VALUES ('keith', '{noop}keithpw','keith@hotmail.com','Keith Htiek','Keith Rd., Keith Garden, keith/F');
INSERT INTO user_roles(name, role) VALUES ('keith', 'ROLE_USER');
INSERT INTO user_roles(name, role) VALUES ('keith', 'ROLE_ADMIN');
INSERT INTO users VALUES ('john', '{noop}johnpw','john@yahoo.com','John Nhoj','John St., John Garden, John/F');
INSERT INTO user_roles(name, role) VALUES ('john', 'ROLE_ADMIN');
INSERT INTO users VALUES ('mary', '{noop}marypw','mary@gmail.com','Mary Yram','Mary Rd., Mary Garden, Mary/F');
INSERT INTO user_roles(name, role) VALUES ('mary', 'ROLE_USER');

insert into BOOK(title, author, description, price, availability) VALUES('test1','author1','description of test1 book by author1',20.5,true)