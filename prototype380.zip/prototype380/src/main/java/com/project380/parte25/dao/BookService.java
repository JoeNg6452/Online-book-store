package com.project380.parte25.dao;

import com.project380.parte25.exception.BookNotFound;
import com.project380.parte25.model.Book;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookService {
    @Resource
    private BookRepository bookRepo;
    private CommentRepository comRepo;

    //Get all books
    public List<Book> getBooks() {
        return bookRepo.findAll();
    }

    //Get one book info
    public Book getBook(int id) throws BookNotFound {
        Book selectedBook = bookRepo.findById(id).orElse(null);
        if (selectedBook == null) {
            throw new BookNotFound(id);
        }
        return selectedBook;
    }
}
