package com.project380.parte25.dao;

import com.project380.parte25.model.Favourite;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface FavouriteRepository extends JpaRepository<Favourite, Integer> {
    List<Favourite> findFavouritesByUsername(String username);

    @Query("select b from Favourite b where b.username=:username and b.book_id=:id")
    Favourite findFavouriteByUsernameAndId(String username, int id);
}
