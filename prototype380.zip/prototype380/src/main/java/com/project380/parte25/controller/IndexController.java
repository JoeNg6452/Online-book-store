package com.project380.parte25.controller;

import com.project380.parte25.dao.AdminService;
import com.project380.parte25.dao.UserManagementService;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.ui.Model;
import org.springframework.web.servlet.ModelAndView;


@Controller
public class IndexController {
    @Resource
    private AdminService adServ;

    @GetMapping("/")
    public String index(){
        return "redirect:/store/list";
    }

    @GetMapping("/login")
        public String login() {
            return "login";
    }

    public static class UserForm {
        private String username;
        private String password;
        private String email;
        private String full_name;
        private String address;

        public String getUsername() {
            return username;
        }

        public void setUsername(String username) {
            this.username = username;
        }

        public String getPassword() {
            return password;
        }

        public void setPassword(String password) {
            this.password = password;
        }

        public String getEmail() {
            return email;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        public String getFull_name() {
            return full_name;
        }

        public void setFull_name(String full_name) {
            this.full_name = full_name;
        }

        public String getAddress() {
            return address;
        }

        public void setAddress(String address) {
            this.address = address;
        }
    }

    @GetMapping("/registration")
    public ModelAndView registrationForm(ModelMap model){
        return new ModelAndView("RegistrationPage","userReg",new UserForm());
    }

    @PostMapping("/registration")
    public String registration(@ModelAttribute("userReg") UserForm form){
        String userRole = "ROLE_USER";
        adServ.createUser(form.getUsername(),form.getPassword(),form.getEmail()
                ,form.getFull_name(),form.getAddress(),userRole);
        return "redirect:/login";
    }

}
