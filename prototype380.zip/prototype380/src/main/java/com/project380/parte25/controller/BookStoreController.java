package com.project380.parte25.controller;

import com.project380.parte25.dao.AdminService;
import com.project380.parte25.dao.BookService;
import com.project380.parte25.dao.CommentService;
import com.project380.parte25.exception.BookNotFound;
import com.project380.parte25.exception.UserNotFound;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.security.Principal;

@Controller
@RequestMapping("/store")
public class BookStoreController {
    @Resource
    private BookService bookServ;
    @Resource
    private CommentService comServ;
    @Resource
    private AdminService adServ;

    @GetMapping(value = {"", "/list"})
    public String list(ModelMap model) {
        model.addAttribute("bookList", bookServ.getBooks());
        return "index";
    }

    @GetMapping("/itemPage/{id}")
    public String itemPage(@PathVariable int id, ModelMap model) throws BookNotFound {
        model.addAttribute("bookItem",bookServ.getBook(id));
        model.addAttribute("comments",comServ.getBookComments(id));
        model.addAttribute("Addcomments",new ComForm());
        return "itemPage";
    }


    public static class ComForm {
        private String comment;

        public String getComment() {
            return comment;
        }

        public void setComment(String comment) {
            this.comment = comment;
        }
    }


    @PostMapping("/itemPage/{id}")
    public String addCom(@ModelAttribute("Addcomment") ComForm form, @PathVariable int id, Principal principal)
            throws UserNotFound,BookNotFound {
        adServ.addCom(principal.getName(), id, form.getComment());
        return "redirect:/store/itemPage/{id}";
    }
}
