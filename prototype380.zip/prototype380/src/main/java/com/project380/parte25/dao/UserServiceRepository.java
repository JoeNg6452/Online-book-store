package com.project380.parte25.dao;

import com.project380.parte25.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserServiceRepository extends JpaRepository <User, String>{

}
