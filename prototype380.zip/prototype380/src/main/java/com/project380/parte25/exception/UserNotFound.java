package com.project380.parte25.exception;

public class UserNotFound extends Exception{
    public UserNotFound(String username){
        super("User "+username+" does not exist");
    }
}
