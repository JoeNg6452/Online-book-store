package com.project380.parte25.dao;

import com.project380.parte25.exception.BookNotFound;
import com.project380.parte25.exception.CartNotFound;
import com.project380.parte25.exception.UserNotFound;
import com.project380.parte25.model.Cart;
import com.project380.parte25.model.Book;
import com.project380.parte25.model.Order;
import com.project380.parte25.model.User;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

@Service
public class CartManagementService {
    @Resource
    private CartRepository cartRepo;
    @Resource
    private BookRepository bookRepo;
    @Resource
    private UserRepository userRepo;

    @Resource
    private OrderRepository orderRepo;

    @Transactional
    public List<Cart> getAllCarts() {
        return cartRepo.findAll();
    }

    //get specific cart entry
    @Transactional
    public Cart getCart(int id) throws CartNotFound {
        Cart cart = cartRepo.findById(id).orElse(null);
        if (cart == null) {
            throw new CartNotFound(id);
        }
        return cart;
    }

    //get user's cart
    @Transactional
    public List<Cart> getUserCart(String username)
            throws UserNotFound {
        try{
            List<Cart> userCarts = cartRepo.findAllByUsername(username);
            return userCarts;
        }catch (Exception e) {
            throw new UserNotFound(username);
        }

    }

    //update a cart entry amount
    @Transactional
    public void delCartItem(int id)
            throws CartNotFound {
        Cart cart = cartRepo.findById(id).orElse(null);
        if (cart == null) {
            throw new CartNotFound(id);
        }
        cartRepo.delete(cart);
    }

    // new cart entry
    @Transactional
    public void createCartItem(String username, int bookid, int count)
            throws BookNotFound, UserNotFound {
        if (count <= 0) {
            return;
        }
        Book book = bookRepo.findById(bookid).orElse(null);
        if (book == null) {
            throw new BookNotFound(bookid);
        }
        User user = userRepo.findById(username).orElse(null);
        if (user == null) {
            throw new UserNotFound(username);
        }
        Cart cart = new Cart();
        cart.setUser(user);
        cart.setBook(book);
        cart.setAmount(count);
        cart.setTotalPrice();
        cart.setBook_id(bookid);
        cart.setUsername(username);
        cartRepo.save(cart);
    }

    @Transactional
    public float checkoutCarts(String username)
            throws CartNotFound {
        List<Cart> carts = cartRepo.findAllByUsername(username);
        if (carts == null) {
            throw new CartNotFound(username);
        }
        float totalAmount = 0;
        for (Cart cart : carts) {
            totalAmount += calTotal(cart.getBook().getPrice(),cart.getAmount());
        }
        return totalAmount;
    }

    public float calTotal(float price, int amount){
        return price*amount;
    }

    @Transactional
    public void updateCart(int cartid,int newAmount)
            throws CartNotFound {
        Cart cart = cartRepo.findById(cartid).orElse(null);
        if (cart == null) {
            throw new CartNotFound(cartid);
        }
        cart.setAmount(newAmount);
        cart.setTotalPrice();
        cartRepo.save(cart);
    }

    public void checkoutItem(int id) throws CartNotFound {
        Cart cart = cartRepo.findById(id).orElse(null);
        if(cart == null){
            throw new CartNotFound(id);
        }
        cartRepo.delete(cart);
        Order order = new Order(cart.getBook().getTitle(), cart.getAmount(), cart.getTotalPrice(), cart.getUsername(), cart.getBook_id());
        orderRepo.save(order);
    }
}
