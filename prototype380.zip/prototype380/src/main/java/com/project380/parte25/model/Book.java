package com.project380.parte25.model;

import jakarta.persistence.*;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.springframework.web.multipart.MultipartFile;

@Entity
@Table(name="book")
public class Book {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="book_id")
    private int id;

    private String title;
    private String author;
    private String description;
    private float price;
    private boolean availability;

    @OneToMany(mappedBy = "bookId",fetch = FetchType.EAGER,
            cascade = CascadeType.MERGE, orphanRemoval = true)
    private List<Comment> comments = new ArrayList<>();

    @OneToMany(mappedBy = "book_id", fetch = FetchType.EAGER, cascade = CascadeType.MERGE, orphanRemoval = true)
    private List<Order> orders = new ArrayList<>();

    @OneToMany(mappedBy = "book_id", fetch = FetchType.EAGER, cascade = CascadeType.MERGE, orphanRemoval = true)
    private List<Favourite> favourites = new ArrayList<>();
    @Column(name="cover")
    @Lob
    private byte[] coverPhotos;

    public Book(){}
    public Book(String title, String author, String description,
                float price, boolean availability) {
        this.title = title;
        this.author = author;
        this.description = description;
        this.price = price;
        this.availability = availability;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public boolean isAvailability() {
        return availability;
    }

    public void setAvailability(boolean availability) {
        this.availability = availability;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCoverPhotos() {
        if (this.coverPhotos != null) {
            return "data:image/png;base64," + Base64.getEncoder().encodeToString(this.coverPhotos);
        }
        return null;
    }

    public void setExPhoto(String exFi){
        String[] path = exFi.split("base64,");
        this.coverPhotos = Base64.getDecoder().decode(path[1]);
    }
    public void setCoverPhotos(MultipartFile fi) throws IOException {
        this.coverPhotos = fi.getBytes();
    }

    public List<Comment> getComments() {
        return comments;
    }

    public void setComments(List<Comment> comments) {
        this.comments = comments;
    }
    public void deleteComment(Comment comment) {
        comment.setBook(null);
        comment.setUser(null);
        this.comments.remove(comment);
    }
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
