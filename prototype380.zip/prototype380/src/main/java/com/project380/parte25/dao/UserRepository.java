package com.project380.parte25.dao;

import com.project380.parte25.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, String> {
}
