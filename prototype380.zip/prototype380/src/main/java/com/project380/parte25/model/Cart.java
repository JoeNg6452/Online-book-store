package com.project380.parte25.model;

import jakarta.persistence.*;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

@Entity
@Table(name="cart")
public class Cart {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="cart_id")
    private int id;

    private String username;
    private int book_id;

    @ManyToOne
    @JoinColumn(name="username", insertable=false, updatable=false)
    @OnDelete(action = OnDeleteAction.CASCADE)
    private User user;

    @ManyToOne
    @JoinColumn(name="book_id", insertable=false, updatable=false)
    @OnDelete(action = OnDeleteAction.CASCADE)
    private Book book;

    private int amount;

    private float total_price;

    public float getTotalPrice() {
        return total_price;
    }

    public void setTotalPrice() {
        this.total_price = this.amount*this.book.getPrice();
    }

    public boolean delAmount(int count){
        if (this.amount <= 0){
            return false;
        }
        this.amount -= count;
        return true;
    }

    public void addAmount(int count){
        this.amount += count;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public Book getBook() {
        return book;
    }

    public void setBook(Book book) {
        this.book = book;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public int getBook_id() {
        return book_id;
    }

    public void setBook_id(int book_id) {
        this.book_id = book_id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    @Override
    public String toString() {
        return "Cart{" +
                "id=" + id +
                ", username='" + username + '\'' +
                ", book_id=" + book_id +
                ", user=" + user +
                ", book=" + book +
                ", amount=" + amount +
                ", total_price=" + total_price +
                '}';
    }
}
