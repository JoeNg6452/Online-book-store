package com.project380.parte25.dao;

import com.project380.parte25.model.Order;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OrderService {
    @Resource
    private OrderRepository orderRepo;

    public List<Order> getOrderHistory(String username){
        return orderRepo.findAllByUsername(username);
    }
}
