package com.project380.parte25.dao;

import com.project380.parte25.exception.BookNotFound;
import com.project380.parte25.exception.UserNotFound;
import com.project380.parte25.model.Book;
import com.project380.parte25.model.Comment;
import com.project380.parte25.model.Favourite;
import com.project380.parte25.model.User;
import jakarta.annotation.Resource;
import org.springframework.security.core.parameters.P;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class UserManagementService {
    @Resource
    private UserRepository suRepo;
    @Resource
    private CommentRepository comRepo;
    @Resource
    private FavouriteRepository favouriteRepo;

    @Resource
    private BookRepository bookRepo;

    @Transactional
    public void delete(String username) throws UserNotFound {
        User StoreUser = suRepo.findById(username).orElse(null);
        if (StoreUser == null) {
            throw new UserNotFound(username);
        }
        suRepo.delete(StoreUser);
    }

    @Transactional
    public List<Comment> getUserComments(String username) throws UserNotFound {
        return comRepo.findAllByUsername(username);
    }

    @Transactional
    public User getUser(String username) throws UserNotFound {
        User selectedUser = suRepo.findById(username).orElse(null);
        if (selectedUser == null) {
            throw new UserNotFound(username);
        }
        return selectedUser;
    }

    @Transactional
    public void updateUser(String username,String password,String full_name,String email,String address)
            throws UserNotFound {
        User selectedUser = suRepo.findById(username).orElse(null);
        if (selectedUser == null) {
            throw new UserNotFound(username);
        }
        selectedUser.setPassword("{noop}"+password);
        selectedUser.setAddress(address);
        selectedUser.setFull_name(full_name);
        selectedUser.setEmail(email);
        suRepo.save(selectedUser);
    }

    @Transactional
    public void addToFav(int bookId, String username){
        Favourite check = favouriteRepo.findFavouriteByUsernameAndId(username, bookId);
        Book book = bookRepo.findById(bookId).orElse(null);
        if(book != null && check == null) {
            Favourite favourite = new Favourite(username, bookId, book.getDescription(), book.getAuthor(), book.getTitle());
            favouriteRepo.save(favourite);
        }
    }

    @Transactional
    public List<Favourite> getUserFav(String username){
        return favouriteRepo.findFavouritesByUsername(username);
    }
@Transactional
    public void removeFav(String username, int id){
        Favourite target = favouriteRepo.findById(id).orElse(null);
    assert target != null;
    Favourite favourite = favouriteRepo.findFavouriteByUsernameAndId(username, target.getBook_id());
        if(favourite != null){
            favouriteRepo.delete(favourite);
        }
    }
}
