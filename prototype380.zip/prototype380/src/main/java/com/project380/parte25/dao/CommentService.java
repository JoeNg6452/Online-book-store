package com.project380.parte25.dao;

import com.project380.parte25.exception.BookNotFound;
import com.project380.parte25.exception.UserNotFound;
import com.project380.parte25.model.Book;
import com.project380.parte25.model.Comment;
import com.project380.parte25.model.User;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class CommentService {
    @Resource
    private CommentRepository comRepo;
    @Resource
    private UserRepository userRepo;
    @Resource
    private BookRepository bookRepo;

    public List<Comment> getBookComments(int bookId) throws BookNotFound {
        Book book = bookRepo.findById(bookId).orElse(null);
        if (book == null) {
            throw new BookNotFound("Book not found");
        }
        return comRepo.findAllByBookTitle(book.getTitle());
    }
}
