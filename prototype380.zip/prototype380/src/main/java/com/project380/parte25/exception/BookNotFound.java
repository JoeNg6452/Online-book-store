package com.project380.parte25.exception;

public class BookNotFound extends Exception{
    public BookNotFound(String title){
        super("Book "+title+" does not exist");
    }
    public BookNotFound(int id){
        super("Book "+id+" does not exist");
    }
}
