package com.project380.parte25.model;

import jakarta.persistence.*;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;
@Entity
@Table(name = "orders")
public class Order {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "order_id")
    private int id;
    private String title;
    private int quantity;
    private float total_price;
    private int book_id;
    private String username;
    @ManyToOne()
    @JoinColumn(name="book_id", insertable=false, updatable=false)
    @OnDelete(action = OnDeleteAction.CASCADE)
    private Book book;

    @ManyToOne()
    @JoinColumn(name="username", insertable=false, updatable=false)
    @OnDelete(action = OnDeleteAction.CASCADE)
    private User user;

    public Order(String title, int quantity, float total_price, String username, int book_id) {
        this.title = title;
        this.quantity = quantity;
        this.total_price = total_price;
        this.username = username;
        this.book_id = book_id;
    }

    public int getBook_id() {
        return book_id;
    }

    public void setBook_id(int bookId) {
        this.book_id = bookId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Order(){
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public float getTotal_price() {
        return total_price;
    }

    public void setTotal_price(float total_price) {
        this.total_price = total_price;
    }

    @Override
    public String toString() {
        return "Order{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", quantity=" + quantity +
                ", total_price=" + total_price +
                ", book_id=" + book_id +
                ", username='" + username + '\'' +
                ", book=" + book +
                '}';
    }
}
