package com.project380.parte25.exception;

public class CartNotFound extends Exception{
    public CartNotFound(int id){
        super("Cart "+id+" not found");
    }
    public CartNotFound(String username){
        super("Cart from "+username+" not found");
    }
}
