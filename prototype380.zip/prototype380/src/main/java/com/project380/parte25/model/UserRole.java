package com.project380.parte25.model;

import jakarta.persistence.*;

@Entity
@Table(name="user_roles")
public class UserRole {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="user_role_id")
    private int id;

    @Column(insertable = false, updatable = false)
    private String name;

    private String role;

    @ManyToOne
    @JoinColumn(name = "name")
    private User user;

    public UserRole() {}

    public UserRole(String name, String role) {
        this.name = name;
        this.role = role;
    }

    public UserRole(String name, String role, User user) {
        this.name = name;
        this.role = role;
        this.user = user;
    }
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "UserRole{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", role='" + role + '\'' +
                ", user=" + user +
                '}';
    }
}
