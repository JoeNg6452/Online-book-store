package com.project380.parte25.controller;

import com.project380.parte25.dao.CartManagementService;
import com.project380.parte25.dao.OrderService;
import com.project380.parte25.dao.UserManagementService;
import com.project380.parte25.dao.UserService;
import com.project380.parte25.exception.BookNotFound;
import com.project380.parte25.exception.CartNotFound;
import com.project380.parte25.exception.UserNotFound;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;

@Controller
@RequestMapping("/self")
public class UserController {
    @Resource
    private UserManagementService uServ;
    @Resource
    private CartManagementService cmServ;
    @Resource
    private OrderService orderServ;

    @GetMapping("/cart")
    public String list(ModelMap model, Principal principal)
            throws UserNotFound {
        String username = principal.getName();
        model.addAttribute("Cart", cmServ.getUserCart(username));
        return "shoppingCart";
    }

//    @GetMapping("/orderhist")
//    public String orderHistory(Principal principal, ModelMap model){
//        return "orderHistory";
//    }

    public static class UserForm {
        private String password;
        private String email;
        private String full_name;
        private String address;

        public String getPassword() {
            return password;
        }

        public void setPassword(String password) {
            this.password = password;
        }

        public String getEmail() {
            return email;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        public String getAddress() {
            return address;
        }

        public void setAddress(String address) {
            this.address = address;
        }

        public String getFull_name() {
            return full_name;
        }

        public void setFull_name(String full_name) {
            this.full_name = full_name;
        }
    }

    @GetMapping("/profile")
    public String userProfile(Principal principal, ModelMap model)
            throws UserNotFound {
        model.addAttribute("userInfo", uServ.getUser(principal.getName()));
        return "profile";
    }

    @GetMapping("/profile/update")
    public String profile(Principal principal, ModelMap model)
            throws UserNotFound {
        model.addAttribute("userUpdateForm", new UserForm());
        model.addAttribute("userInfo", uServ.getUser(principal.getName()));
        return "userProfile";
    }
    @PostMapping("/profile/update")
    public String updatedProfile(@ModelAttribute("userUpdateForm") UserForm form, Principal principal)
            throws UserNotFound {
        uServ.updateUser(principal.getName(),form.getPassword(),
                form.getFull_name(),form.getEmail(),form.getAddress());
        return "redirect:/self/profile";
    }

    @GetMapping("/comhist")
    public String comhist(Principal principal, ModelMap model)
            throws UserNotFound {
        model.addAttribute("comList",uServ.getUserComments(principal.getName()));
        return "commentHistory";
    }

    @GetMapping("/orderhist")
    public String orderhist(Principal principal, ModelMap model)
            throws UserNotFound {
        model.addAttribute("orders",orderServ.getOrderHistory(principal.getName()));
        return "orderHistory";
    }

    @GetMapping("/checkout/{id}")
    public String checkoutItem(@PathVariable("id") int id) throws CartNotFound {
        cmServ.checkoutItem(id);
        return "redirect:/self/orderhist";
    }

    @GetMapping("/addToFav/{id}")
    public String addToFav(@PathVariable("id") int book_id, Principal principal) throws BookNotFound {
        uServ.addToFav(book_id, principal.getName());
        return "redirect:/store/list";
    }

    @GetMapping("/fav")
    public String userFavourite(ModelMap model, Principal principal){
        model.addAttribute("favourites", uServ.getUserFav(principal.getName()));
        return "myFavourite";
    }

    @GetMapping("/removeFav/{id}")
    public String removeFav(@PathVariable("id")int id, Principal principal){
        uServ.removeFav(principal.getName(), id);
        return "redirect:/self/fav";
    }
}
