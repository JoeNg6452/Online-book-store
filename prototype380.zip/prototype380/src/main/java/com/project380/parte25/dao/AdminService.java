package com.project380.parte25.dao;

import com.project380.parte25.exception.BookNotFound;
import com.project380.parte25.exception.ComNotFound;
import com.project380.parte25.exception.UserNotFound;
import com.project380.parte25.model.*;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

@Service
public class AdminService {
    @Resource
    private UserRepository userRepo;
    @Resource
    private BookRepository bookRepo;
    @Resource
    private CommentRepository comRepo;

    @Resource
    private OrderRepository orderRepo;

    @Resource
    private UserRoleRepository userRoleRepo;

    //User CRUD
    @Transactional
    public List<User> getUsers() {
        return userRepo.findAll();
    }

    @Transactional
    public User getUser(String username)
            throws UserNotFound{
        User user = userRepo.findById(username).orElse(null);
        if (user == null) {
            throw new UserNotFound(username);
        }
        return user;
    }

    @Transactional(rollbackFor = UserNotFound.class)
    public void deleteUser(String username) throws UserNotFound {
        User deletedUser = userRepo.findById(username).orElse(null);
        if (deletedUser == null) {
            throw new UserNotFound(username);
        }
        userRepo.delete(deletedUser);
    }

    @Transactional
    public void createUser(String username,String password,String email,
                           String full_name,String address,String role) {
        User newUser = new User(username,password,email,full_name,address,role);
        UserRole userRole = new UserRole(username, role, newUser);
        userRepo.save(newUser);
        userRoleRepo.save(userRole);
    }

    @Transactional
    public void updateUser(String username,String password,String email,
                           String full_name,String address,String role)
            throws UserNotFound {
        User selectedUser = userRepo.findById(username).orElse(null);
        if (selectedUser == null) {
            throw new UserNotFound(username);
        }
        //save a user with updated attributes
        selectedUser.setPassword("{noop}"+password);
        selectedUser.setEmail(email);
        selectedUser.setFull_name(full_name);
        selectedUser.setAddress(address);
        UserRole user_role = userRoleRepo.findByName(username);
        userRoleRepo.save(user_role);
        selectedUser.setRole(role);
        userRepo.save(selectedUser);
    }

    //Comment CRUD
    @Transactional
    public void addCom(String username, int id, String comment)
            throws BookNotFound,UserNotFound {
        User user = userRepo.findById(username).orElse(null);
        Book book = bookRepo.findById(id).orElse(null);
        if (book == null) {
            throw new BookNotFound(id);
        }
        if (user == null) {
            throw new UserNotFound(username);
        }
        Comment newComment = new Comment();
        newComment.setComment(comment);
        newComment.setUser(user);
        newComment.setBook(book);
        newComment.setDate(new Date(System.currentTimeMillis()));
        book.getComments().add(newComment);
        bookRepo.save(book);
    }

    @Transactional
    public List<Comment> getComments() {
        return comRepo.findAll();
    }

    @Transactional
    public void delCom(int id,int bookid)
            throws ComNotFound,BookNotFound {
        Book book = bookRepo.findById(bookid).orElse(null);
        Comment com = comRepo.findById(id).orElse(null);
        if (book == null) {
            throw new BookNotFound(id);
        }
        if (com == null) {
            throw new ComNotFound(id);
        }
        book.deleteComment(com);
        bookRepo.save(book);
        comRepo.delete(com);
    }

    //Book availability CRUD
    @Transactional
    public void changeAvail(int id) throws BookNotFound {
        Book selectedBook = bookRepo.findById(id).orElse(null);
        if (selectedBook == null) {
            throw new BookNotFound(id);
        }
        boolean avail = selectedBook.isAvailability();
        selectedBook.setAvailability(!avail);
        bookRepo.save(selectedBook);
    }

    //Item CRUD
    @Transactional
    public void addBook(String title, String author, String description,
                        float price, boolean availability,
                        MultipartFile fi) throws IOException {
        Book newBook = new Book(title,author,description,price,availability);
        newBook.setCoverPhotos(fi);
        bookRepo.save(newBook);
    }

    @Transactional
    public void delBook(int bookid) throws BookNotFound {
        Book selectedBook = bookRepo.findById(bookid).orElse(null);
        if (selectedBook == null) {
            throw new BookNotFound(bookid);
        }
        comRepo.deleteAllByBookId(bookid);
        bookRepo.delete(selectedBook);
    }

    @Transactional
    public void updateBook(int id,String title, String author, String description,
                           float price, boolean availability, String exFi,MultipartFile fi)
            throws BookNotFound, IOException {
        Book selectedBook = bookRepo.findById(id).orElse(null);
        if (selectedBook == null) {
            throw new BookNotFound(title);
        }
        List<Comment> exCom = selectedBook.getComments();
        //save the book with updated attributes
        selectedBook.setTitle(title);
        selectedBook.setAuthor(author);
        selectedBook.setDescription(description);
        selectedBook.setPrice(price);
        selectedBook.setAvailability(availability);
        selectedBook.setComments(exCom);
        if (fi.isEmpty()){
            selectedBook.setExPhoto(exFi);
        }else {
            selectedBook.setCoverPhotos(fi);
        }
        bookRepo.save(selectedBook);
    }

    public List<Order> getAllOrders(){
        return orderRepo.findAll();
    }

    public void delOrder(int id) {
        orderRepo.delete(orderRepo.findById(id).orElse(null));
    }
}
