package com.project380.parte25.controller;

import com.project380.parte25.dao.BookService;
import com.project380.parte25.dao.CartManagementService;
import com.project380.parte25.dao.UserManagementService;
import com.project380.parte25.exception.BookNotFound;
import com.project380.parte25.exception.CartNotFound;
import com.project380.parte25.exception.UserNotFound;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.View;
import org.springframework.web.servlet.view.RedirectView;

import java.io.IOException;
import java.security.Principal;

@Controller
@RequestMapping("/shoppingCart")
public class CartManagementController {
    @Resource
    private CartManagementService cmServ;
    @Resource
    private BookService bookServ;

    public static class CartForm{
        private int bookid;
        private String username;
        private int orderCount;
        private float bookAmount;

        public int getBookid() {
            return bookid;
        }

        public void setBookid(int bookid) {
            this.bookid = bookid;
        }

        public float getBookAmount() {
            return bookAmount;
        }

        public void setBookAmount(float bookAmount) {
            this.bookAmount = bookAmount;
        }

        public int getOrderCount() {
            return orderCount;
        }

        public void setOrderCount(int orderCount) {
            this.orderCount = orderCount;
        }

        public String getUsername() {
            return username;
        }

        public void setUsername(String username) {
            this.username = username;
        }
    }

    @GetMapping("/addItem/{bookid}")
    public String addItemConf(@PathVariable("bookid") int bookid, ModelMap model)
            throws BookNotFound {
        model.addAttribute("bookInfo",bookServ.getBook(bookid));
        model.addAttribute("toCart", new CartForm());
        return "addItemConf";
    }

    @PostMapping("/addItem/{bookid}")
    public String addItem(@ModelAttribute("toCart") CartForm form, @PathVariable("bookid") int bookid, Principal principal) throws IOException, BookNotFound, UserNotFound {
        cmServ.createCartItem(principal.getName(), bookid, form.getOrderCount());
        return "redirect:/self/cart";
    }

    @GetMapping("/removeItem/{cartid}")
    public String removeItem(@PathVariable("cartid") int cartid) throws IOException, CartNotFound {
        cmServ.delCartItem(cartid);
        return "redirect:/self/cart";
    }

    @GetMapping("/updateItem/{cartid}")
    public String updateItem(@PathVariable("cartid") int cartid,ModelMap model)
            throws CartNotFound {
        model.addAttribute("bookInfo",cmServ.getCart(cartid).getBook());
        model.addAttribute("oriCart",cmServ.getCart(cartid));
        model.addAttribute("toCart", new CartForm());
        return "updateItemConf";
    }

    @PostMapping("/updateItem/{cartid}")
    public String updatedItem(@ModelAttribute("toCart") CartForm form,@PathVariable("cartid") int cartid,ModelMap model)
            throws CartNotFound {
        cmServ.updateCart(cartid,form.getOrderCount());
        return "redirect:/self/cart";
    }

    @GetMapping("/checkout")
    public String checkoutCarts(Principal principal, ModelMap model)
            throws CartNotFound, UserNotFound {
        model.addAttribute("allCartItems", cmServ.getUserCart(principal.getName()));
        model.addAttribute("totalPrice",cmServ.checkoutCarts(principal.getName()));
        return "checkoutCarts";
    }

    @GetMapping("/confirm")
    public String purchased(Principal principal, ModelMap model)
            throws UserNotFound {
        cmServ.recordOrder(cmServ.getUserCart(principal.getName()));
        cmServ.clearCart(principal.getName());
        model.addAttribute("username",principal.getName());
        return "confirmPurchase";
    }
}
