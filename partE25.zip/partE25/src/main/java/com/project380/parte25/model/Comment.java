package com.project380.parte25.model;

import jakarta.persistence.*;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.sql.Date;

@Entity
@Table(name="comments")
public class Comment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private String comment;

    @Column(insertable=false, updatable=false)
    private int bookId;

    @Column(insertable=false, updatable=false)
    private String username;

    @ManyToOne()
    @JoinColumn(name="bookId")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private Book book;

    @ManyToOne()
    @JoinColumn(name="username")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private User user;

    @Column(name="created_date")
    private Date date;

    public Comment(){}
    public Comment(String comment, Book book, User user, Date date) {
        this.comment = comment;
        this.book = book;
        this.user = user;
        this.date = date;
    }
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Book getBook() {
        return book;
    }

    public void setBook(Book book) {
        this.book = book;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public int getBookId() {
        return bookId;
    }

    public void setBookId(int bookId) {
        this.bookId = bookId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }
}
