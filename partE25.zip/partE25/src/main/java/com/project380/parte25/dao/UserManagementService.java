package com.project380.parte25.dao;

import com.project380.parte25.exception.UserNotFound;
import com.project380.parte25.model.Comment;
import com.project380.parte25.model.User;
import jakarta.annotation.Resource;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class UserManagementService {
    @Resource
    private UserRepository suRepo;
    @Resource
    private CommentRepository comRepo;

    @Transactional
    public void delete(String username) throws UserNotFound {
        User StoreUser = suRepo.findById(username).orElse(null);
        if (StoreUser == null) {
            throw new UserNotFound(username);
        }
        suRepo.delete(StoreUser);
    }

    @Transactional
    public List<Comment> getUserComments(String username) throws UserNotFound {
        return comRepo.findAllByUsername(username);
    }

    @Transactional
    public User getUser(String username) throws UserNotFound {
        User selectedUser = suRepo.findById(username).orElse(null);
        if (selectedUser == null) {
            throw new UserNotFound(username);
        }
        return selectedUser;
    }

    @Transactional
    public void updateUser(String username,String password,String full_name,String email,String address)
            throws UserNotFound {
        User selectedUser = suRepo.findById(username).orElse(null);
        if (selectedUser == null) {
            throw new UserNotFound(username);
        }
        selectedUser.setPassword(password);
        selectedUser.setAddress(address);
        selectedUser.setFull_name(full_name);
        selectedUser.setEmail(email);
        suRepo.save(selectedUser);
    }

}
