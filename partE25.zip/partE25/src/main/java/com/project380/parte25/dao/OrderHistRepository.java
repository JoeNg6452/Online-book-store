package com.project380.parte25.dao;

import com.project380.parte25.model.OrderHist;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface OrderHistRepository extends JpaRepository<OrderHist,Integer> {
    List<OrderHist> findAllByUsername(String username);
}
