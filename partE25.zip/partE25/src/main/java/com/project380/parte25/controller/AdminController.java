package com.project380.parte25.controller;

import com.project380.parte25.dao.AdminService;
import com.project380.parte25.dao.BookService;
import com.project380.parte25.dao.CartManagementService;
import com.project380.parte25.exception.*;
import com.project380.parte25.model.Comment;
import com.project380.parte25.model.User;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import java.io.IOException;
import java.util.List;

@Controller
@RequestMapping("/admin")
public class AdminController {
    @Resource
    AdminService adServ;
    @Resource
    BookService bookServ;
    @Resource
    CartManagementService caServ;

    @GetMapping({"/userlist"})
    public String userlist(ModelMap model){
        model.addAttribute("users",adServ.getUsers());
        return "listUser";
    }

    @GetMapping("/userlist/{username}")
    public String oneUser(@PathVariable("username") String username, ModelMap model)
            throws UserNotFound {
        model.addAttribute("userEntry",adServ.getUser(username));
        return "UserManage";
    }

    public static class UserForm {
        private String username;
        private String password;
        private String email;
        private String full_name;
        private String address;
        private String[] roles;

        public String getUsername() {
            return username;
        }

        public void setUsername(String username) {
            this.username = username;
        }

        public String getPassword() {
            return password;
        }

        public void setPassword(String password) {
            this.password = password;
        }

        public String getEmail() {
            return email;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        public String getAddress() {
            return address;
        }

        public void setAddress(String address) {
            this.address = address;
        }

        public String getFull_name() {
            return full_name;
        }

        public void setFull_name(String full_name) {
            this.full_name = full_name;
        }

        public String[] getRoles() {
            return roles;
        }

        public void setRoles(String[] roles) {
            this.roles = roles;
        }
    }

    // Using path ./admin/userlist
    // User CRUD
    @GetMapping("/createUser")
    public ModelAndView createUser(){
        return new ModelAndView("addUser","addUserForm",new UserForm());
    }

    @PostMapping("/createUser")
    public String create(@ModelAttribute("addUserForm") UserForm form) throws IOException {
        adServ.createUser(form.getUsername(), form.getPassword(),
                form.getEmail(),form.getFull_name(),
                form.getAddress(),form.getRoles());
        return "redirect:/admin/userlist";
    }

    @GetMapping("/deleteUser/{username}")
    public String deleteUser(@PathVariable("username") String username)
            throws UserNotFound {
        adServ.deleteUser(username);
        return "redirect:/admin/userlist";
    }

    @GetMapping("/editUser/{username}")
    public String edit(@PathVariable("username") String username,ModelMap model)
            throws UserNotFound {
        model.addAttribute("userEntry",adServ.getUser(username));
        model.addAttribute("userForm",new UserForm());
        return "editUser";
    }

    @PostMapping("/editUser/{username}")
    public String editUser(@ModelAttribute("userForm") UserForm form)
            throws UserNotFound {
        adServ.updateUser(form.getUsername(),form.getPassword(),form.getAddress(),
                form.getFull_name(),form.getAddress(), form.getRoles());
        return "redirect:/admin/userlist/{username}";
    }

    // Comments page using path ./admin/comments
    // Comments CRUD
    @GetMapping("/comments")
    public String listComments(ModelMap model){
        model.addAttribute("comments",adServ.getComments());
        return "listComments";
    }

    @GetMapping("/delCom/{bookid}/{id}")
    public String delComFromBook(@PathVariable("id") int id, @PathVariable("bookid") int bookid)
            throws ComNotFound, BookNotFound {
        adServ.delCom(id,bookid);
        return "redirect:/store/itemPage/{bookid}";
    }

    // Item page
    @GetMapping(value = {"", "/list"})
    public String booklist(ModelMap model) {
        model.addAttribute("bookList", bookServ.getBooks());
        return "index";
    }

    // Availability change
    @GetMapping("/availSwap/{id}")
    public String availSwap(@PathVariable("id") int id)
            throws BookNotFound {
        adServ.changeAvail(id);
        return "redirect:/store/itemPage/{id}";
    }

    public static class BookForm{
        private String title;
        private String author;
        private String description;
        private float price;
        private boolean available;
        private MultipartFile fi;
        private String comment;
        private User user;
        private String exFi;

        public String getExFi() {
            return exFi;
        }

        public void setExFi(String exFi) {
            this.exFi = exFi;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public MultipartFile getFi() {
            return fi;
        }

        public void setFi(MultipartFile fi) {
            this.fi = fi;
        }

        public boolean isAvailable() {
            return available;
        }

        public void setAvailable(boolean available) {
            this.available = available;
        }

        public float getPrice() {
            return price;
        }

        public void setPrice(float price) {
            this.price = price;
        }

        public String getDescription() {
            return description;
        }

        public void setDescription(String description) {
            this.description = description;
        }

        public String getAuthor() {
            return author;
        }

        public void setAuthor(String author) {
            this.author = author;
        }

        public String getComment() {
            return comment;
        }

        public void setComment(String comment) {
            this.comment = comment;
        }

        public User getUser() {
            return user;
        }

        public void setUser(User user) {
            this.user = user;
        }
    }


    @GetMapping("/addBook")
    public ModelAndView addBook(){
        return new ModelAndView("BookManage","bookList",new BookForm());
    }

    // Book CRUD
    @PostMapping("/addBook")
    public String createBook(BookForm form)
            throws IOException, WrongFileType {
        try{
            adServ.addBook(form.getTitle(),form.getAuthor(),form.getDescription(),
                    form.getPrice(),form.isAvailable(),form.getFi());
            return "redirect:/store/list";
        }catch(WrongFileType e){
            return "redirect:/store/list";
        }
    }

    @GetMapping("/updateBook/{bookid}")
    public String updateBookForm(@PathVariable("bookid") int bookid,ModelMap model)
            throws BookNotFound {
        model.addAttribute("theBook",bookServ.getBook(bookid));
        model.addAttribute("bookUpdateForm",new BookForm());
        return "updateBook";
    }

    @PostMapping("/updateBook/{bookid}")
    public String updateBook(@PathVariable("bookid") int bookid,@ModelAttribute("bookUpdateForm") BookForm form)
            throws BookNotFound, IOException {
        adServ.updateBook(bookid,form.getTitle(),form.getAuthor(),form.getDescription(),
                form.getPrice(),form.isAvailable(),form.getExFi(),form.getFi());
        return "redirect:/store/itemPage/{bookid}";
    }

    @GetMapping("/deleteBook/{id}")
    public String deleteBook(@PathVariable("id") int id)
            throws BookNotFound{
        adServ.delBook(id);
        return "redirect:/store/list";
    }

    @GetMapping("/orderhist")
    public String orderhist(ModelMap model)
            throws BookNotFound, UserNotFound, CartNotFound {
        model.addAttribute("orders",caServ.getAllOrderHist());
        return "orderHistory";
    }
}
