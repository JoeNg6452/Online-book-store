package com.project380.parte25.exception;

public class WrongFileType extends Exception{
    public WrongFileType(){
        super("Wrong File Type");
    }
}
