INSERT INTO users VALUES ('keith', '{noop}keithpw','keith@hotmail.com','Keith Htiek','Keith Rd., Keith Garden, keith/F');
INSERT INTO user_roles(name, role) VALUES ('keith', 'ROLE_USER');
INSERT INTO user_roles(name, role) VALUES ('keith', 'ROLE_ADMIN');
INSERT INTO users VALUES ('john', '{noop}johnpw','john@yahoo.com','John Nhoj','John St., John Garden, John/F');
INSERT INTO user_roles(name, role) VALUES ('john', 'ROLE_ADMIN');
INSERT INTO users VALUES ('mary', '{noop}marypw','mary@gmail.com','Mary Yram','Mary Rd., Mary Garden, Mary/F');
INSERT INTO user_roles(name, role) VALUES ('mary', 'ROLE_USER');
INSERT INTO users VALUES ('pepe','{noop}pepepw','pepeEmailAddress123','pepeFullName','pepeRd. 321 pepe/F');
INSERT INTO user_roles(name, role) VALUES ('pepe', 'ROLE_USER');
INSERT INTO user_roles(name, role) VALUES ('pepe', 'ROLE_ADMIN');

INSERT INTO BOOK(title, author, description, price, availability,COVER) VALUES('Book testing 2','big author','description of Book testing 2 book by big author',13.8,true,FILE_READ('D:\HKMU Assignment\Year 4\Sem 2\380\Project\partE25\src\main\resources\static\bookCover.jpg'));
INSERT INTO BOOK(title, author, description, price, availability,COVER) VALUES('test1','author1','description of test1 book by author1',20.5,true,FILE_READ('D:\HKMU Assignment\Year 4\Sem 2\380\Project\partE25\src\main\resources\static\bookCover.jpg'));
INSERT INTO BOOK(title, author, description, price, availability,COVER) VALUES('tester 2 book 3','smaller author','description of tester 2 book 3 book by smaller author',69.3,false,FILE_READ('D:\HKMU Assignment\Year 4\Sem 2\380\Project\partE25\src\main\resources\static\bookCover.jpg'));

INSERT INTO COMMENTS(comment, username, book_id, created_date)
VALUES('comment about test1 is very good, would recommend to everyone',
'pepe',1,'2019-7-31');
INSERT INTO COMMENTS(comment, username, book_id, created_date)
VALUES('comment about test1 is very bad, would not recommend to everyone, I also hate the pepe user very much!!1!!11!!',
       'keith',1,'2023-4-21');
INSERT INTO COMMENTS(comment, username, book_id, created_date)
VALUES('comment about test1 is not important, this keith user is very rude to pepe',
       'mary',1,'2024-1-16');
INSERT INTO COMMENTS(comment, username, book_id, created_date)
VALUES('comment about second book here',
       'pepe',2,'2012-2-21');
INSERT INTO COMMENTS(comment, username, book_id, created_date)
VALUES('comment about third book, would not recommend!!1!!11!!',
       'keith',3,'2024-4-5');
INSERT INTO COMMENTS(comment, username, book_id, created_date)
VALUES('straight fire',
       'mary',2,'2014-2-16');

INSERT INTO CART(username, book_id, amount,total_price)
VALUES ('pepe','1',5,19);
INSERT INTO CART(username, book_id, amount,TOTAL_PRICE)
VALUES ('keith','1',1,65);
INSERT INTO CART(username, book_id, amount,TOTAL_PRICE)
VALUES ('mary','1',3,23);

INSERT INTO ORDER_HIST(username, book_title, total_price, total_quantity, order_date)
VALUES ('pepe','test1',41,2,'2018-3-2');
INSERT INTO ORDER_HIST(username, book_title, total_price, total_quantity, order_date)
VALUES ('keith','book in the past',6,3,'2015-9-14');
INSERT INTO ORDER_HIST(username, book_title, total_price, total_quantity, order_date)
VALUES ('keith','book unavailable',32,8,'2020-2-1');
INSERT INTO ORDER_HIST(username, book_title, total_price, total_quantity, order_date)
VALUES ('mary','Book testing 2',13.8,1,'2024-3-6');
INSERT INTO ORDER_HIST(username, book_title, total_price, total_quantity, order_date)
VALUES ('mary','tester 2 book 3',69.3,1,'2024-4-14');